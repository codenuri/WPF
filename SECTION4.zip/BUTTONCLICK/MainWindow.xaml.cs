﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BUTTONCLICK
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, RoutedEventArgs e)
        {
        //    Button btn = (Button)sender;

         //   Console.WriteLine($"{btn.Name}, {btn.Content},{btn.Tag}");
        }

        private void StackPanel_Click(object sender, RoutedEventArgs e)
        {
            //Button btn = (Button)sender; // stack panel 자체의 참조

            Button btn = (Button)e.Source;

            Console.WriteLine($"{btn.Name}, {btn.Content},{btn.Tag}");
        }
    }
}
