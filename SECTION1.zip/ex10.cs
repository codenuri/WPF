﻿// ex10.cs
using System;
using System.Windows;

class Program
{
    public static void Main()
    {
        Application app = new Application();

        Console.WriteLine("Hello, WPF");

        app.Run();

    }
}
