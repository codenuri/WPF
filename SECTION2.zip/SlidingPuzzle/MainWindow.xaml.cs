﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SlidingPuzzle
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {

        // Step 1.
        private const int COUNT = 5;
        private const int EMPTY = COUNT * COUNT - 1;

        public void InitGameGrid()
        {
            for (int i = 0; i < COUNT; i++)
            {
                gameGrid.RowDefinitions.Add(new RowDefinition());
                gameGrid.ColumnDefinitions.Add(new ColumnDefinition());
            }
        }

        private int[,] board = new int[COUNT, COUNT];


        public void InitBoard()
        {
            for (int y = 0; y < COUNT; y++)
            {
                for (int x = 0; x < COUNT; x++)
                {
                    board[y, x] = y * COUNT + x;
                }
            }
        }


        private double width = 0;
        private double height = 0;

        public void DrawGameGrid()
        {
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri("D:\\totoro.jpg");
            bitmap.EndInit();

            width = bitmap.Width / COUNT;
            height = bitmap.Height / COUNT;

            for (int y = 0; y < COUNT; y++)
            {
                for (int x = 0; x < COUNT; x++)
                {
                    if (board[y, x] != EMPTY)
                    {
                        int no = board[y, x];
                        int bx = no % COUNT;
                        int by = no / COUNT;

                        CroppedBitmap cb = new CroppedBitmap(bitmap,
                                            new Int32Rect((int)(bx * width), (int)(by * height),
                                                    (int)width, (int)height));

                        Image img = new Image();
                        //img.Source = bitmap; // 전체 그림.
                        img.Source = cb; // 한개 블럭 그림
                        img.Stretch = Stretch.Fill;
                        img.Margin = new Thickness(0.5);

                        Grid.SetRow(img, y);
                        Grid.SetColumn(img, x);

                        gameGrid.Children.Add(img);
                    }
                }

            }
        }

        public MainWindow()
        {
            InitializeComponent();
            InitBoard();
            InitGameGrid();
            DrawGameGrid();
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);

            //Point pt = e.GetPosition(this); // MainWindow 기준 좌표
            Point pt = e.GetPosition(gameGrid);

            int bx = (int)(pt.X / (gameGrid.ActualWidth / COUNT));
            int by = (int)(pt.Y / (gameGrid.ActualHeight / COUNT));

            if (bx < 0 || by < 0 || bx >= COUNT || by >= COUNT) return;

            // 상하좌우 조사
            if (bx < COUNT - 1 && board[by, bx + 1] == EMPTY) // RIGHT 가 empty
            {
                SwapBlock(bx, by, bx + 1, by);
            }
            else if (bx > 0 && board[by, bx - 1] == EMPTY) // Left 가 empty
            {
                SwapBlock(bx, by, bx - 1, by);
            }
            else if (by < COUNT - 1 && board[by + 1, bx] == EMPTY)
            {
                SwapBlock(bx, by, bx, by + 1);
            }
            else if (by > 0 && board[by - 1, bx] == EMPTY)
            {
                SwapBlock(bx, by, bx, by - 1);
            }
            else
            {
                SystemSounds.Beep.Play();
                return;
            }
            // 다 맞추었는지 확인
        }

        public void SwapBlock(int x1, int y1, int x2, int y2)
        {
            // 배열값 교환
            int temp = board[y1, x1];
            board[y1, x1] = board[y2, x2];
            board[y2, x2] = temp;

            // grid내부의 image 교환
            Image img1 = gameGrid.Children.Cast<Image>().FirstOrDefault(n => Grid.GetRow(n) == y1 && Grid.GetColumn(n) == x1);
            Image img2 = gameGrid.Children.Cast<Image>().FirstOrDefault(n => Grid.GetRow(n) == y2 && Grid.GetColumn(n) == x2);

            if (img1 != null)
            {
                Grid.SetRow(img1, y2);
                Grid.SetColumn(img1, x2);
            }

            if (img2 != null)
            {
                Grid.SetRow(img2, y1);
                Grid.SetColumn(img2, x1);
            }
        }
    }
}

