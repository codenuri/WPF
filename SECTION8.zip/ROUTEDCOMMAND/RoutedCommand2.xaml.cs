﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ROUTEDCOMMAND
{
    /// <summary>
    /// RoutedCommand2.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class RoutedCommand2 : Window
    {
        public RoutedCommand2()
        {
            InitializeComponent();
        }

        private void Cmd_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = !string.IsNullOrEmpty(txtBox.Text);
        }

        private void Cmd_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show(txtBox.Text);
        }
    }
}
